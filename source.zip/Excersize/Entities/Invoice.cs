﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Excersize.Entities
{
    public class Invoice
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string InvoiceId { get; set; }
        public string invoiceNumber { get; set; }
        public string Status { get; set; }
        public DateTime DueDateUtc { get; set; }
        public DateTime CreatedDateUtc { get; set; }
        public DateTime UpdatedDateUtc { get; set; }
        public List<InvoiceItem> InlineItems { get; set; }
    }
}
