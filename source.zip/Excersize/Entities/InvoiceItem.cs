﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Excersize.Entities
{
    public class InvoiceItem
    {
        public string ItemId { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public decimal UnitCost { get; set; }
        public decimal TotalCost { get { return Quantity * UnitCost; } }
    }
}
