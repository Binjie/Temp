﻿using System;
using System.Collections.Generic;
using System.Text;
using Excersize.Entities;

namespace Excersize.Module
{
    public interface IInvoiceDataLoader
    {
        List<Invoice> Load(string path);
    }
}
