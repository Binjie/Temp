﻿using Excersize.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Excersize.Module
{
    public interface IInvoiceGenerator
    {
        public void Generate(Invoice invoice, string path);
    }
}
