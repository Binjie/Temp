﻿using Excersize.Entities;
using Excersize.Utility;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Text.Json;

namespace Excersize.Module
{
    public class JsonInvoiceDataLoader : IInvoiceDataLoader
    {

        public List<Invoice> Load(string path)
        {
            var json = WebHelper.Request(path);

            return JsonToInvoice(json);
        }

        private List<Invoice> JsonToInvoice(string json)
        {
            //Build Entity
            List<Invoice> invoices = new List<Invoice>();
            using (JsonDocument doc = JsonDocument.Parse(json))
            {
                if (doc.RootElement.TryGetProperty("items", out JsonElement jeItems))
                {
                    var elemArray = jeItems.EnumerateArray();
                    foreach (JsonElement item in elemArray)
                    {
                        var invoice = new Invoice();
                        if (item.TryGetProperty("id", out JsonElement jeId)) { invoice.Id = jeId.GetInt32(); }
                        if (item.TryGetProperty("type", out JsonElement jeType)) { invoice.Type = jeType.GetString(); }
                        if (item.TryGetProperty("content", out JsonElement jeContent))
                        {
                            if (jeContent.TryGetProperty("status", out JsonElement jeStatus)) { invoice.Status = jeStatus.GetString(); }
                            if (jeContent.TryGetProperty("dueDateUtc", out JsonElement jeDue)) { invoice.DueDateUtc = jeDue.GetDateTime(); }
                            if (jeContent.TryGetProperty("createdDateUtc", out JsonElement jeCreated)) { invoice.CreatedDateUtc = jeCreated.GetDateTime(); }
                            if (jeContent.TryGetProperty("updatedDateUtc", out JsonElement jeUpdated)) { invoice.UpdatedDateUtc = jeUpdated.GetDateTime(); }
                            if (jeContent.TryGetProperty("invoiceId", out JsonElement jeInvoiceId)) { invoice.InvoiceId = jeInvoiceId.GetString(); }
                            if (jeContent.TryGetProperty("invoiceNumber", out JsonElement jeInvoiceNumber)) { invoice.invoiceNumber = jeInvoiceNumber.GetString(); }
                            if (jeContent.TryGetProperty("lineItems", out JsonElement jeLineItems))
                            {
                                invoice.InlineItems = new List<InvoiceItem>();
                                foreach (JsonElement lineitem in jeLineItems.EnumerateArray())
                                {
                                    var invoiceItem = new InvoiceItem();
                                    if (lineitem.TryGetProperty("lineItemId", out JsonElement jeLineItemId)) { invoiceItem.ItemId = jeLineItemId.GetString(); }
                                    if (lineitem.TryGetProperty("description", out JsonElement jeDes)) { invoiceItem.Description = jeDes.GetString(); }
                                    if (lineitem.TryGetProperty("quantity", out JsonElement jeQuantity)) { invoiceItem.Quantity = jeQuantity.GetInt32(); }
                                    if (lineitem.TryGetProperty("unitCost", out JsonElement jeUnitCost)) { invoiceItem.UnitCost = jeUnitCost.GetDecimal(); }
                                    invoice.InlineItems.Add(invoiceItem);
                                }
                            }
                        }
                        invoices.Add(invoice);
                    }
                }
                return invoices;
            }
        }

    }
}