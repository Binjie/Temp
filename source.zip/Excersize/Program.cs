﻿using System;
using System.IO;
using System.Threading.Tasks;
using Excersize.Config;
using Excersize.Module;
using Excersize.Utility;

namespace Excersize
{
    class Program
    {
        private const string AFTEREVENTIDFILE = "AFTEREVENTID.FILE";
        static void Main(string[] args)
        {
            if (args.Length < 2)
            {
                Console.WriteLine("Please input correct parameters");
                return;
            }
            //Get parameters
            var url = args[0];
            var path = args[1];

            //Set page size and after eventid if not in URL
            if (!url.Contains("pageSize"))
            {
                url = WebHelper.BuildUrl(url, "pageSize", Config.Config.GetSettings("pageSize"));
            }
            if (!url.Contains("afterEventId"))
            {
                //Load last invoice id
                url = WebHelper.BuildUrl(url, "afterEventId", GetAfterEventId().ToString());
            }

            //Run
            while (true)
            {
                try
                {
                    //Load Invoices
                    IInvoiceDataLoader invoicesLoader = new JsonInvoiceDataLoader();
                    var invoices = invoicesLoader.Load(url);
                    //Process Invoice
                    IInvoiceGenerator generator = new PDFInvoiceGenerator();
                    foreach (var invoice in invoices)
                    {
                        try
                        {
                            generator.Generate(invoice, path);
                            //save last invoice to file 
                            SaveAfterEventId(invoice.Id);
                            //update url for next time execution
                            url = WebHelper.BuildUrl(url, "afterEventId", invoice.Id.ToString());
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                var interval = Convert.ToInt32(Config.Config.GetSettings("RequireInterval"));
                Task.Delay(interval).Wait();
            }
        }
        private static int GetAfterEventId()
        {
            if (!File.Exists(AFTEREVENTIDFILE))
            {
                return 0;
            }
            string readText = File.ReadAllText(AFTEREVENTIDFILE);
            return Convert.ToInt32(readText);
        }
        private static void SaveAfterEventId(int id)
        {
            string text = id.ToString();
            File.WriteAllText(AFTEREVENTIDFILE, text);
        }
    }
}
