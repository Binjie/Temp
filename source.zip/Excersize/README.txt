﻿Split this function into 2 steps. 1. get invoice data from webapi. 2. save invoice to pdf File
Code Structure
Config: Read config file app.settings.json
Entities: invtntity class Invoice
Module: Function Folder. 
	2 Interface: IInvoiceDalaLoader: load invoice data. IInvoiceGenerator: save invoice
	2 implements: JsonInvoiceDataLoader: load data from json web api. PDFInvoiceGenerator: save invoice to pdf file.
Utility: Common functions

execute step:
1. process parameters. 
2. get invoice data
3. save invoice data to pdf file.
4. update parameters. save last invoice id in file and update url.
5. sleep and wait then repeat steps.