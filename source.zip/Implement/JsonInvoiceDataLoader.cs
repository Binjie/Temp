﻿using Excersize.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace Excersize.Module
{
    public class JsonInvoiceDataLoader : IInvoiceDataLoader
    {
        public Invoice Load(string path)
        {
            //get data from webapi
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(path);
            request.Proxy = null;
            request.KeepAlive = false;
            request.Method = "GET";
            request.ContentType = "application/json; charset=UTF-8";
            request.AutomaticDecompression = DecompressionMethods.GZip;

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.UTF8);
            string retString = myStreamReader.ReadToEnd();

            myStreamReader.Close();
            myResponseStream.Close();

            if (response != null)
            {
                response.Close();
            }
            if (request != null)
            {
                request.Abort();
            }

            retString;

            var result = JsonConvert.DeserializeObject<Invoice>(json);
        }
    }
}
