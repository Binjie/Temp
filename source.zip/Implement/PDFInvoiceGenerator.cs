﻿using Excersize.Entities;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Excersize.Module
{
    public class PDFInvoiceGenerator : IInvoiceGenerator
    {
        void IInvoiceGenerator.Generate(Invoice invoice, string path)
        {
            var pdfpath = Path.Combine(path, invoice.Id.ToString());
            //Generate PDF
            Document document = new Document();
            var fileStream = File.Create(pdfpath);
            PdfWriter pw = PdfWriter.GetInstance(document, fileStream);

            Paragraph pInvoiceNumber = new Paragraph("Invoice Number: " + invoice.invoiceNumber);
            Paragraph pDueDate = new Paragraph("Due Date: " + invoice.DueDateUtc.ToShortDateString());
            document.Add(pInvoiceNumber);
            document.Add(pDueDate);

            //itemlist
            PdfPTable tableRow_1 = new PdfPTable(1);//first Row
            tableRow_1.DefaultCell.Border = Rectangle.NO_BORDER;
            tableRow_1.DefaultCell.MinimumHeight = 40f;
            float[] headWidths_1 = new float[] { 500f };
            tableRow_1.SetWidths(headWidths_1);

            var Row_1_Cell_1 = new PdfPCell(new Paragraph("Invoice Items"));
            Row_1_Cell_1.HorizontalAlignment = Element.ALIGN_CENTER;
            tableRow_1.AddCell(Row_1_Cell_1);

            PdfPTable tableRow_2 = new PdfPTable(5);
            tableRow_2.DefaultCell.Border = Rectangle.NO_BORDER;
            tableRow_2.DefaultCell.MinimumHeight = 40f;
            float[] headWidths_2 = new float[] { 80f, 100f, 80f, 100f, 140f };
            tableRow_2.SetWidths(headWidths_2);
            var Row_2_Cell_1 = new PdfPCell(new Paragraph("Item Id"));
            tableRow_2.AddCell(Row_2_Cell_1);

            var Row_2_Cell_2 = new PdfPCell(new Paragraph("Description"));
            tableRow_2.AddCell(Row_2_Cell_2);

            var Row_2_Cell_3 = new PdfPCell(new Paragraph("Quantity"));
            tableRow_2.AddCell(Row_2_Cell_3);

            var Row_2_Cell_4 = new PdfPCell(new Paragraph("Unit Cost"));
            tableRow_2.AddCell(Row_2_Cell_4);

            var Row_2_Cell_5 = new PdfPCell(new Paragraph("Total Cost"));
            tableRow_2.AddCell(Row_2_Cell_5);
            document.Add(tableRow_1);
            document.Add(tableRow_2);

            foreach (var invoiceitem in invoice.InlineItems)
            {
                PdfPTable tableRow_3 = new PdfPTable(5);
                tableRow_3.DefaultCell.Border = Rectangle.NO_BORDER;
                tableRow_3.DefaultCell.MinimumHeight = 40f;
                float[] headWidths_3 = new float[] { 80f, 100f, 80f, 100f, 140f };
                tableRow_3.SetWidths(headWidths_3);
                var Row_3_Cell_1 = new PdfPCell(new Paragraph(invoiceitem.ItemId));
                tableRow_3.AddCell(Row_3_Cell_1);

                var Row_3_Cell_2 = new PdfPCell(new Paragraph(invoiceitem.Description));
                tableRow_3.AddCell(Row_3_Cell_2);

                var Row_3_Cell_3 = new PdfPCell(new Paragraph(invoiceitem.Quantity));
                tableRow_3.AddCell(Row_3_Cell_3);

                var Row_3_Cell_4 = new PdfPCell(new Paragraph(invoiceitem.UnitCost));
                tableRow_3.AddCell(Row_3_Cell_4);

                var Row_3_Cell_5 = new PdfPCell(new Paragraph(invoiceitem.TotalCost));
                tableRow_3.AddCell(Row_3_Cell_5);
                document.Add(tableRow_3);
            }
            document.Close();
            fileStream.Dispose();
        }
    }
}
